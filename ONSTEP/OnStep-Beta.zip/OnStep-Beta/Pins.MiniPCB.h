// -------------------------------------------------------------------------------------------------
// Pin map for OnStep MiniPCB (Teensy3.2)

#warning "Pin-maps in OnStep have moved to the src/pinmaps/ directory, your configuration file's second to last line should be updated."
#include "src/pinmaps/Pins.MiniPCB.h"

