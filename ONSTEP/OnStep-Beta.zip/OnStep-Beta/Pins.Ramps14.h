// -------------------------------------------------------------------------------------------------
// Pin map for OnStep using RAMPS 1.4 Shield (Arduino Mega2560 or Arduino DUE)

#warning "Pin-maps in OnStep have moved to the src/pinmaps/ directory, your configuration file's second to last line should be updated."
#include "src/pinmaps/Pins.Ramps14.h"

