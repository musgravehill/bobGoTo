#pragma once
#include "Pad.h"

uint8_t ext_GetMenuEvent(Pad* extPad);