OnStep Telescope Controller
===========================

# Other configuration files

These are less frequently used configurations.

To activate one of these I recommend opening the file (you can use the Arduino IDE to do this if you like) and copy it's contents over the contents of Config.Classic.h (copy/paste.)  
Then follow the directions to enable the configuration as you would any other (OnStep Wiki.)
