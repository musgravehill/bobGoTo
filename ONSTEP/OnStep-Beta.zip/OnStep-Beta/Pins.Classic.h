// -------------------------------------------------------------------------------------------------
// Pin map for legacy OnStep Classic (Mega2560 or Teensy3.x)

#warning "Pin-maps in OnStep have moved to the src/pinmaps/ directory, your configuration file's second to last line should be updated."
#include "src/pinmaps/Pins.Classic.h"

