// -------------------------------------------------------------------------------------------------
// Pin map for legacy OnStep "Alternate pin-map" (Mega2560)

#warning "Pin-maps in OnStep have moved to the src/pinmaps/ directory, your configuration file's second to last line should be updated."
#include "src/pinmaps/Pins.Mega2560Alt.h"

