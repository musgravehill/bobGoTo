// -------------------------------------------------------------------------------------------------
// Pin map for OnStep Launchpad TM4C varients

#warning "Pin-maps in OnStep have moved to the src/pinmaps/ directory, your configuration file's second to last line should be updated."
#include "src/pinmaps/Pins.TM4C.h"

